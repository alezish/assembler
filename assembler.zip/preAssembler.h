#ifndef PRE_ASSEMBLER_H
#define PRE_ASSEMBLER_H 


#define MACRO_START_WORD "mcro"
#define MACRO_END_WORD "mcroend"


void handle_pre_assembler_for_file(char * file_name);
#endif